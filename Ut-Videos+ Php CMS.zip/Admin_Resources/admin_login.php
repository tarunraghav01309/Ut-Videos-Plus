<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Admin panel-login</title>
<link href="./css/style.css" rel="stylesheet">
</head>
<style>
body {
    color: white;  
   background-color: #333333;
   border: 2px solid #35FFFF;
  border-radius: 9px;
  outline: none;
   
  }
  
  body:hover {
   color: #35FFFF;
   background-color: #333333;
   border: 1px solid #35FFFF;
   border-radius: 9px;
   outline: none;
  }
  
#Frame0 {
	background-color: #353646;
	margin: 30px auto auto;
	padding: 10px;
	width: auto;
	border: 1px solid silver;
	border-radius: 8px;
}

</style>
<body>
<meta name="viewport" content="width=device-width, initial-scale=1">
<div id="Frame0">
  <h1>Admin login</h1>
</div>
<br>
<form action="authentication.php" method="post" name="Login_Form">
  <table width="100%" border="0" align="center" cellpadding="5" cellspacing="1" class="Table">
    <?php if(isset($msg)){?>
    <tr>
      <td colspan="2" align="center" valign="top"><?php echo $msg;?></td>
    </tr>
    <?php } ?>
    <tr>
      <td colspan="2" align="left" valign="top"><h3>Login</h3></td>
    </tr>
    <tr>
      <td align="right" valign="top">Username</td>
      <td><input name="Username" type="text" class="Input"></td>
    </tr>
    <tr>
      <td align="right">Password</td>
      <td><input name="Password" type="password" class="Input"></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><input name="Submit" type="submit" value="Login" class="Button3"></td>
    </tr>
  </table>
</form>
</body>
</html>
