# remote-file-upload
This is a Remote File Upload PHP Script by Pure Coding.
