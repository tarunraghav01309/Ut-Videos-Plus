<!Doctype Html>
<html>
	<head>
		<title>File Share</title>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="ie=edge">
		<style type="text/css">
			td{
				padding: 30px;
			}
			.btn{
				padding: 10px;
				color: #fff;
				background-color: #000;
				width: 120px;
				border: none;
				cursor: pointer;
			}
		</style>
	</head>
	<body>
		<center>
			<h1>File Share</h1>
			<h4 style="color:red;">Make Sure both Sender and receiver connected to same network</h4>
			<a href="send.php" ><input class="btn" type="button" value="Share" /></a><br/><br/>
			<a href="receive.php" ><input class="btn" type="button" value="Receive" /></a>
		</center>
	</body>
</html>
