<?php session_start(); /* Starts the session */

if(!isset($_SESSION['UserData']['Username'])){
	header("location:Admin_Resources/admin_login.php");
	exit;
}
?>

<!Doctype Html>
<html>
	<head>
		<title>Delete Files</title>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="ie=edge">
		<style type="text/css">
			.btn{
				padding: 10px;
				color: #fff;
				background-color: #000;
				width: 120px;
				border: none;
				cursor: pointer;
			}
			.delbtn{
				padding: 5px;
				color: #fff;
				background-color: red;
				width: 80px;
				border: none;
				cursor: pointer;
			}
		</style>
	</head>
	<body>
<center>
<h1>Delete Files</h1>
<button onClick="window.location.href=window.location.href">Refresh</button>
<br/><br/>


<?php
	$files = scandir("uploads");
	for($i = 2; $i < count($files); $i++){
		echo $files[$i] . " ";?><form action="?" method="POST"><button name="delete" class="delbtn" value="<?php echo $files[$i]; ?>">Delete</button></form><br/><br/><?php
	}
	if(isset($_POST['delete'])){
		$path = "uploads/" . $_POST['delete'];
		unlink($path);
       // header("location:delete.php");
	}
?>
	</body>
</center>
</html>
