<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Ut-Videos +</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<!--Website Logo-->
<link rel="shortcut icon" type="image/png" href="inc/favicon.png"/>
<link type="text/css" rel="stylesheet" href="darkmode.css" />
<script src="https://kit.fontawesome.com/2641fe0f3e.js" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" />
<style>
/* Floating Buttons */

*{
  padding:0;
  margin:0;
}

body{
	font-family:Verdana, Geneva, sans-serif;
/*
	background-color:#CCC;
*/
	font-size:12px;
}

.label-container{
	position: fixed;
	bottom:48px;
	right:105px;
	display:table;
	visibility: hidden;
}

.label-text{
	color:#FFF;
	background:rgba(51,51,51,0.5);
	display:table-cell;
	vertical-align:middle;
	padding:10px;
	border-radius:3px;
}

.label-arrow{
	display:table-cell;
	vertical-align:middle;
	color:#333;
	opacity:0.5;
}

.float{
	position: fixed;
	width:60px;
	height:60px;
	bottom:40px;
	right:40px;
	background-color:#F33;
	color:#FFF;
	border-radius:50px;
	text-align:center;
	box-shadow: 2px 2px 3px #999;
	z-index:1000;
	animation: bot-to-top 2s ease-out;
}


.floatup{
	position: fixed;
	width:60px;
	height:60px;

	bottom:258px;

	right:40px;
	background-color:#F33;
	color:#FFF;
	border-radius:50px;
	text-align:center;
	box-shadow: 2px 2px 3px #999;
	z-index:1000;


}

ul{
      /*
	position: fixed;
*/
	right:40px;
	padding-bottom:20px;
	bottom:80px;
	z-index:100;
}


ul li{
	list-style:none;
	margin-bottom:10px;
}

ul li a{
	background-color:#F33;
	color:#FFF;
	border-radius:50px;
	text-align:center;
	box-shadow: 2px 2px 3px #999;
	width:60px;
	height:60px;
	display: block;
}

ul:hover{
	visibility:visible!important;
	opacity:1!important;
}


.my-float{
	font-size:24px;
	margin-top:18px;
}

a#menu-share + ul{
  visibility: hidden;
}

a#menu-share:hover + ul{
  visibility: visible;
  animation: scale-in 0.5s;
}

a#menu-share i{
	animation: rotate-in 0.5s;
}

a#menu-share:hover > i{
	animation: rotate-out 0.5s;
}


@keyframes bot-to-top {
    0%   {bottom:-40px}
    50%  {bottom:40px}
}

@keyframes scale-in {
    from {transform: scale(0);opacity: 0;}
    to {transform: scale(1);opacity: 1;}
}

@keyframes rotate-in {
    from {transform: rotate(0deg);}
    to {transform: rotate(360deg);}
}

@keyframes rotate-out {
    from {transform: rotate(360deg);}
    to {transform: rotate(0deg);}
}

</style>
<!-- Don't Change The Position of following " link Tags" -->
<link rel="stylesheet" type="text/css" href="inc/style.css"/>
    <!-- style for media insertion -->
    <link rel="stylesheet" type="text/css" href="inc/ins-media.css"/>
</head>
<body>


<header><div><h1>Ut-Videos +</h1>
<form action="search.php" method="get"><input name="formname"
type="text" placeholder="search..."> <input type="submit" value="search"></form>
<br></br>
</div></header>


    <!-- media insertion -->
    <?php include "inc/ins-media.php"; ?>

<a href="#" class="float" id="menu-share">
<i class="fa fa-plus my-float"></i>
</a>
<ul class="floatup">
<li><a href="fileshare/send.php">
<i class="fa fa-upload my-float"></i>
</a></li>
<li><a href="admin.php">
<i class="fa fa-bars my-float"></i>
</a></li>
<li><a href="#" onclick="toggleThemeColor()" id="toggleThemeColor">
<span id="icon" class="far fa-moon fa fa-moon my-float"></span>
</a></li>
</ul>

<!-- Dark Mode Button
<button onclick="toggleThemeColor()" id="toggleThemeColor">
  <i id="icon" class="far fa-moon"></i>
</button>
-->
<!--Right Arrow icon
<i class="fa fa-long-arrow-alt-right my-float"></i>
-->
<!--Left Arrow icon
<i class="fa fa-long-arrow-alt-left my-float"></i>
-->
</div>
<script src="darkmode.js"></script>
</body>
<!--
    <footer><div><?php echo date("Y"); ?> // source code <a target="_blank" href="https://github.com/dvdn/show-all-media-in-a-folder-with-php">dvdn/show-all-media-in-a-folder-with-php</a></div></footer>
-->
</html>
