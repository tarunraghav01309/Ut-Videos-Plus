# Ut-Videos-Plus
' Ut-Videos+ ' is a Video CMS Php Script , Works fully without MySql Database.etc

Admin Panel (admin.php)-
Default login details:
username= admin
password= Hpsc@123







