<!DOCTYPE html>
<html>
    <head>
        <title>url-file-uploader-2</title>
<meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="style.css" />
        <script type="text/javascript" src="jquery.js"></script>
        <script type="text/javascript">
        $(document).ready(function(){
            $("#1").hide();
        });
        function uploadfile()
        {
            var sds = document.getElementById("dum");
            if(sds == null){
            alert("You are using a free package.\n You are not allowed to remove the copyright.\n");
        }
        var sdss = document.getElementById("dumdiv");
        if(sdss == null){
            alert("You are using a free package.\n You are not allowed to remove the copyright.\n");
        }
        if(sdss != null)
        { 
            $("#1").show();
            $("#disp").html("");
            var url = encodeURIComponent($("#url").val());
            $.ajax({
                url: "upload.php",
                data: "url=" +url,
                type: 'post',
                success: function(data)
                {
                    var findsucc = data.indexOf("successfully");
                    out=data.split('**$$**');
                    if(findsucc!=-1)
                    {
                        $("#disp").css({"color": "green"});
                        $("#disp").html(out[0]);
                        $("#link").html("<a href='../upload/"+out[1]+"'>Click here</a> to view");
                        $("#1").hide();
                    }
                    else
                    {
                        $("#1").hide();
                        $("#disp").css({"color": "red"});
                        $("#disp").html(data);
                        $("#url").val("");
                    }
                }
            });
        }
        }
        </script>
    </head>
<body>
<div class="container">
      <div class="remote-upload">
<div align='center' style='padding-top: 40px;color: #4e4e4e;'><h1 class="title">Url File Uploader-2</h1>
<div class="inputBox">
<div align='center' style="text-align: left; padding-top: 10px; padding-bottom: px;" class="form-label">
Enter Remote URL: 
</div>
<style>
.form-control2:hover{
outline: 1px solid blue; 
padding-top: 10px;
}
</style>
<input class="form-control2" style="border: 1px solid silver; height: 50px;" type="text" name="url" id='url' size="35">
<br></br>

 <input 
 class="btn" type="submit" value="Upload" name="submit" style='cursor: pointer;' onclick='uploadfile()'>&nbsp;&nbsp;<img src='ajax-loader.gif' id='1'>&nbsp;&nbsp;<br /><br />
<div align='center'><span id='disp'></span></div>
<br>
<div id='link'></div><br />
<div style=" padding-left: 20px;font-size: 10px;color: #dadada;" id="dumdiv"></div>

<h5>Valid file Types:-</h5>
<div style="outline: 1px solid #dadada; color: green;" width: auto; height: auto;">
<h5 style="padding-top: 3px;">("mp4","mpeg","php","html","js","zip","jpeg","gif","png",
"doc","docx","jpg","css","asp","xml","JPEG","bmp","3gp",
"webm")
</h5>
</div>

<style>
.btn2 {
				padding: 10px;
				color: #fff;
				background-color: #000;
				width: 120px;
				border: 1px solid #35FFFF;
				cursor: pointer;
                                border-radius: 10px;
			} 
.btn2:hover{
     color: white;
    background: #FF3333; 
     }
</style>
<center>
<p style="padding-bottom: 5px;"></p>
<a href="../send.php"><button class="btn2">Home</button></a></center>


<br>
<a href="http://www.hscripts.com" id="dum" style="padding-right:0px; text-decoration:none;color: green;">&copy;h</a></div>
</div>
</div>
</div>
</body>
</html>
