<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Search Results...</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {
  box-sizing: border-box;
}


body {
    color: white;  
   background-color: #333333;
   border: ;
  border-radius: 9px;
  outline: none;
  padding-top: 10%;
  padding-bottom: 10%;
/*
  padding-right; 50%;
*/
  }
  
  body:hover {
   color: #35FFFF;
   background-color: ;
   border: none;
   border-radius: 9px;
   outline: none;
  }

    div {
width: 90%;
  height: 95%;
  background: silver;
  border: 2px dotted white;
  overflow-x: hidden;
  overflow-y: scroll;
}

div:hover {
border: 2px solid #35FFFF;
}

h4{
color: white;
}
 a{
 display: none;
}
</style>
</head>
<body>
<center>

<form action="search.php" method="get"><input name="formname" placeholder="Search Files..."
type="text"> <input type="submit" value="Search">
</form>
<h4>Your Search Results...</h4>
<div>


<?php
$dir = 'uploads'; 
$exclude = array('.','..','.htaccess'); 
$q = (isset($_GET['formname']))? strtolower($_GET['formname']) : ''; 
$res = opendir($dir); 
while(false!== ($file = readdir($res))) { 
if(strpos(strtolower($file),$q)!== false &&!in_array($file,$exclude)) { 

echo "<video width='320' height='240' controls>";  echo "<source src='$dir/$file'>$file type='video/mp4'>";
 echo "</video>";

echo "
<object data='' width='320' height='240'>
   <img src='$dir/$file' width='320' height='240'>
</object>
<p>File Name:-</p>
<h4>$file</h4>
<div>
</div>
"; 

echo "<br>"; 
} 
} 
closedir($res); 
?>

</div>
</center>

<!-- Hide Tags if not in use-
<script>
var v = document.querySelector('video'),
    sources = v.querySelectorAll('source'),
    lastsource = sources[sources.length-1];
lastsource.addEventListener('error', function(ev) {
  v.parentNode.style.display = 'none';
}, false);
</script>
-->
<script>
this.contentDocument.querySelector('video').pause()" 
</script>
</body>
</html>