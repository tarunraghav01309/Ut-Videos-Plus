<?php session_start(); /* Starts the session */

if(!isset($_SESSION['UserData']['Username'])){
	header("location:Admin_Resources/admin_login.php");
	exit;
}
?>

<!doctype html>
<html>
<head>
  <title>Welcome to Admin Panel</title>
<style>
body {
    color: white;  
   background-color: #333333;
   border: none;
  border-radius: 9px;
  outline: none;
   
  }
  
  body:hover {
   color: #35FFFF;
   background-color: #333333;
   border: none;
   border-radius: 9px;
   outline: none;
  }
  
   .frame03 {
   align-items: center;
   background-color: #F7F7F7;
   margin: 30px auto auto;
   padding: 10px;
   width: 100%;
   border: 2px solid #EEE;
   
   }

  
  #color01 {
    color: white;  
   background-color: #353640;
   border: 1px solid white;
  border-radius: 9px;
  outline: none;
   
  }
  
  #color01:hover {
   color: #35FFFF;
   background-color: #353646;
   border: 1px solid #35FFFF;
   border-radius: 9px;
   outline: none;
  }
  
  
 .buttons {
   color: white;
   background-color: #009922;
   border: 1px solid #333333;
   text-align: center;
   border-radius: 5px;
}
  
 .buttons:hover {
   color: white;
   background-color: #00CC33;
   text-align: center;
   border-radius: 6px;
   outline: none;
   border: 3px solid #444444;
  }
</style>    
</head>
<body>
<meta name="viewport" content="width=device-width, initial-scale=1">
 <div id="color01" class="frame03">
        
<h1> Admin Panel</h1>
<p></p>

<a class="buttons" href="Admin_Resources/logout.php">Log Out</a>
        
<p></p>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {
  box-sizing: border-box;
}

#myInput {
  background-color : #f1f1f1;
  background-position: 10px 12px;
  background-repeat: no-repeat;
  width: 80%;
  font-size: 16px;
  padding: 12px 20px 12px 40px;
  border: 1px solid #ddd;
  margin-bottom: 12px;
  
  display: inline-black;
  padding: 10px 20px;
 
  text-decoration: none;
  color: #333333;
  border:2px solid black;
  border-radius: 7px;
  outline: ;
  
}

#myInput:hover {
  border:2px solid skyblue;
  background-color: white;
  border-radius: 9px;
  outline: ;
  
}

input[type="text"]::placeholder {  
    text-align: center;
}


#myUL {
  list-style-type: none;
  padding: 0;
  margin: 0;
  
   color: green;
   background-color: #364655;
   border: 2px solid #333333;
   
   text-align: center;
  
  /*scroll list*/
  overflow-x: hidden; 
 
  overflow-y: auto; 
  
  text-align:justify; 
  height: 300px
   
}

#myUL li a {
  border: 1px solid #ddd;
  margin-top: -1px; /* Prevent double borders */
  background-color: #f6f6f6;
  padding: 12px;
  text-decoration: none;
  font-size: 18px;
  color: black;
  display: block
}


#myUL li a:hover:not(.header) {
 color: white;
 background-color: #2196F3;
 border: 3px solid skyblue;
border-radus: 5px; 
  text-align: center;
  
}

</style>
</head>
<body>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {
  font-family: Arial;
}

* {
  box-sizing: border-box;
}

div.search input[type=text] {
  padding: 10px;
  font-size: 17px;
  border: 1px solid grey;
  float: left;
  width: 80%;
  background: #f1f1f1;
}

div.search button {
  float: left;
  width: 20%;
  height: 15%;
  padding: 10px;
  background: #2196F3;
  color: white;
  font-size: 17px;
  border: 1px solid black;
  border-left: none;
  cursor: pointer;
}

div.search button:hover {
  background: #0b7dda;
}

div.search::after {
  content: "";
  clear: both;
  display: table;
}
</style>
</head>
<body>

<div class="search">
<form action="search.php" method="get">
<input id="myInput" name="formname" title="Search" 
type="text" placeholder="Search Files...">
<button style="border-radius: 8px;" type="submit" value=""><i  class="fa fa-search"></i></button>
</form>
</div>


<!--
<div class="search">
<input type="text" onkeyup="myFunction()" id="myInput" placeholder="Search.." title="Search">
<button style="border-radius: 8px;" onClick="myFunction()" type="submit" value=""><i  class="fa fa-search"></i></button>
</div>
-->


<ul id="myUL">        
<li><a href="receive.php">View/Download Files</a></li>
<li><a href="fileshare/send.php">Add/Upload Files</a></li>
<li><a href="rename.php">Rename Files</a></li>
<li><a href="delete.php">Delete Files</a></li>
<li><a href="https://www.gaijin.at/en/tools/php-obfuscator">Php-code Encryptor</a></li>
<li><a href="index.php">Open-Website</a></li>


<li><a class="buttons" href="Admin_Resources/logout.php">Log Out</a>
        </li>
      
</ul>

<script>
function myFunction() {
    var input, filter, ul, li, a, i, txtValue;
    input = document.getElementById("myInput");
    filter = input.value.toUpperCase();
    ul = document.getElementById("myUL");
    li = ul.getElementsByTagName("li");
    for (i = 0; i < li.length; i++) {
        a = li[i].getElementsByTagName("a")[0];
        txtValue = a.textContent || a.innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
            li[i].style.display = "";
        } else {
            li[i].style.display = "none";
        }
    }
}
</script>

</body>
</html>



 </div>
</body>
</html>